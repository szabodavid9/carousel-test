import { combineReducers } from 'redux';
import carousel from '../carousel/reducers/reducer_carousel';

export default combineReducers({
  carousel
});